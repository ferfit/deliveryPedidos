<div>
    <div class="container mx-auto">
        <input wire:model="search" class="form-control mt-3 w-50" type="search"
            placeholder="Buscar categoria por nombre...">
        <table class="table bg-white shadow mt-2">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th style="width: 200px">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($categoria->id); ?></td>
                    <td><?php echo e($categoria->nombre); ?></td>
                    <td>
                        <div class="row mx-auto">
                            <a href="<?php echo e(route('admin.categorias.edit', $categoria )); ?>" class="btn btn-primary mr-2">Editar</a>
                        
                            <form action="<?php echo e(route('admin.categorias.destroy', $categoria)); ?>" method="POST" >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input type="submit" class="btn btn-danger d-inline mr-1  "
                                    value="Eliminar">
                            </form>
                        </div>
                        
                    </td>
                </tr>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </tbody>
        </table>
        <div class=" mx-auto">
            <?php echo e($categorias->onEachSide(0)->links()); ?>

        </div>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\deliveryPedidos\resources\views/livewire/categoria-index.blade.php ENDPATH**/ ?>