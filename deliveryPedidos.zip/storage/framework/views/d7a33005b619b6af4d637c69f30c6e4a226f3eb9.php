

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    


        <div class="col-md-6 mt-5 py-4 mx-auto bg-white rounded shadow-lg">

            <h2 class="text-center mt-3">Crear nuevo categoria</h2>
            
            <form method="POST" action="<?php echo e(route ('admin.categorias.store' )); ?>" novalidate>
                <?php echo csrf_field(); ?>
                <div class="form-group my-5 mx-2">
                    <label for="titulo">Nombre</label>
                    <input type="text" 
                    name="nombre" 
                    class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nombre"
                        value="">
                    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group mx-2">
                    <input type="submit" class="btn btn-success shadow rounded" value="Agregar categoria">
                    <a href="<?php echo e(route('admin.categorias.index' )); ?>" class="btn btn-secondary mr-2">Volver</a>
                </div>

            </form>
        
        </div>
        
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deliveryPedidos\resources\views/admin/categorias/create.blade.php ENDPATH**/ ?>