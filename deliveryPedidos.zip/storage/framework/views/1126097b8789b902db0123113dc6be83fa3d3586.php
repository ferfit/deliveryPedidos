

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container my-4">    
</div>


<div class="container mt-2 ">
    <div class="container mx-auto">
        <div class="card shadow">
            <div class="card-header">
              <h3 class="card-title">
                Información del pedido Nro <?php echo e($ordene->id); ?>

              </h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <dl>
                <dt>Franquiciado</dt>
                <dd><?php echo e($ordene->nombre); ?></dd>
                <dt>Razón Social</dt>
                <dd><?php echo e($ordene->user->razonSocial); ?></dd>
                <dt>Dirección</dt>
                <dd><?php echo e($ordene->user->direccion); ?></dd>
                <dt>Cuit</dt>
                <dd><?php echo e($ordene->user->cuit); ?></dd>
                
                <dt>Total a pagar</dt>
                <dd>$<?php echo e($ordene->total); ?></dd>
                <dt>Estado</dt>
                <?php switch( $ordene->estado ):
                                case (1): ?>
                                    <small class="badge badge-warning"> Pendiente</small>
                                    <?php break; ?>
                                <?php case (2): ?>
                                    <small class="badge badge-primary"> En proceso</small>
                                    <?php break; ?>
                                <?php case (3): ?>
                                    <small class="badge badge-success"> Enviado</small>
                                    <?php break; ?>
                                <?php case (0): ?>
                                    <small class="badge badge-danger"> Cancelado</small>
                                    <?php break; ?>
                                <?php default: ?>
                                    
                <?php endswitch; ?>
              </dl>
            </div>
            <!-- /.card-body -->
        </div>

        <table class="table  table bg-white shadow mt-2">
            
            <thead>
                <tr>
                    <th>Codigo</th>
                    <th>Nombre</th>
                    <th>Cantidad</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($producto->options->codigo); ?></td>
                    <td><?php echo e($producto->name); ?></td>
                    <td><?php echo e($producto->qty); ?></td>
                    <td>$<?php echo e($producto->price); ?></td>
                </tr>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </tbody>
        </table>

        
        <div class="mx-auto">
            <div class="row mx-auto mt-3">
                 <a href="<?php echo e(route('admin.imprimir',$ordene)); ?>" class="btn btn-success mr-2">  <i class="fas fa-file-export mr-1" shadow></i> Excel </a>
                 <a href="<?php echo e(route('admin.ordens.index' )); ?>" class="btn btn-secondary mr-2 shadow">Volver</a>
            </div>
        </div>
    </div>
    
    
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deliveryPedidos\resources\views/admin/ordenes/show.blade.php ENDPATH**/ ?>