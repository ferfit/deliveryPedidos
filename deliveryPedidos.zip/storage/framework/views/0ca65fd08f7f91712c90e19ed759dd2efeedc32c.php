

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="container my-4">
        <h1 class="tart">Listado de productos</h1>
    </div>

    <div class="container mt-2 ">
        <a href="<?php echo e(route('admin.productos.create' )); ?>" class="btn btn-success shadow">Crear producto</a>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('producto-index')->html();
} elseif ($_instance->childHasBeenRendered('9qnhB32')) {
    $componentId = $_instance->getRenderedChildComponentId('9qnhB32');
    $componentTag = $_instance->getRenderedChildComponentTagName('9qnhB32');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9qnhB32');
} else {
    $response = \Livewire\Livewire::mount('producto-index');
    $html = $response->html();
    $_instance->logRenderedChild('9qnhB32', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\delibery\resources\views/admin/productos/index.blade.php ENDPATH**/ ?>