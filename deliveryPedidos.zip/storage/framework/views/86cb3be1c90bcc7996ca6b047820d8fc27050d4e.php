<table>
    <thead>
    <tr>
        <th>Codigo</th>
        <th>Nombre</th>
        <th>Cantidad</th>
        <th>Subtotal</th>
    </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($p->options->codigo); ?></td>
            <td><?php echo e($p->name); ?></td>
            <td><?php echo e($p->qty); ?></td>
            <td><?php echo e($p->price); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </tbody>
</table>

<table>
    <thead>
    <tr>
        
        <th >Cliente</th>
        <th></th>
        <th></th>
        <th >Total</th>

    </tr>
    </thead>
    <tbody>
       
        <tr>
            <td><?php echo e($ordene->nombre); ?></td>
            <td></td>
            <td></td>
            <td><?php echo e($ordene->total); ?></td>
        </tr>
    
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\deliveryPedidos\resources\views/admin/ordenes/excel.blade.php ENDPATH**/ ?>