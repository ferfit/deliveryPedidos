<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
        <?php echo \Livewire\Livewire::styles(); ?>



        
    </head>
    <body class="antialiased">

    

        

        <div class="container-fluid p-0 m-0 cabecera">
            
            <?php if(Route::has('login')): ?>
                <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block ml-2">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/admin')); ?>" class="text-sm text-gray-700 underline bg-danger p-1 rounded text-light text-decoration-none">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 underline bg-danger p-1 rounded text-light text-decoration-none">Login</a>

                        
                    <?php endif; ?>
                </div>
                
            <?php endif; ?>
            <div class="d-flex justify-content-center align-items-center">
                <img src="img/logo.png" alt="">
            </div>
            
        </div>

        
            <div id="carrito-icono" class="carrito container shadow rounded p-2 bg-white">
                
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dropdown-cart')->html();
} elseif ($_instance->childHasBeenRendered('TnntH3J')) {
    $componentId = $_instance->getRenderedChildComponentId('TnntH3J');
    $componentTag = $_instance->getRenderedChildComponentTagName('TnntH3J');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TnntH3J');
} else {
    $response = \Livewire\Livewire::mount('dropdown-cart');
    $html = $response->html();
    $_instance->logRenderedChild('TnntH3J', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        


        
        <div class="container"  id="cont-producto">
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h2 class=" text-center text-danger mt-5"><?php echo e($categoria->nombre); ?></h2>
                <br>
                
                <div class="row justify-content-center">
                <?php $__currentLoopData = $categoria->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
                    
                    <div   class="col-5 col-md-2 bg-white menu-item mx-1 mx-md-2 my-3 shadow p-3 rounded d-flex flex-column justify-content-center align-items-center">
                        <img src="/storage/<?php echo e($producto->imagen); ?>" alt="" class="w-75 rounded-circle d-block mx-auto ">
                        <h3 class="nombre_producto mt-2 text-center" data_titulo="<?php echo e($producto->titulo); ?>" ><?php echo e($producto->nombre); ?></h3>
                        <p class="descripcion_producto m-0 text-center"><?php echo e(Str::limit ( strip_tags ( $producto->descripcion ), 100 )); ?></p>
                        <p class="text-center mt-2"><strong>$ <span class="text-center mx-auto"><?php echo e($producto->precio); ?></span></strong></p>


                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cantidad-producto',['producto' => $producto])->html();
} elseif ($_instance->childHasBeenRendered($producto->id)) {
    $componentId = $_instance->getRenderedChildComponentId($producto->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($producto->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($producto->id);
} else {
    $response = \Livewire\Livewire::mount('cantidad-producto',['producto' => $producto]);
    $html = $response->html();
    $_instance->logRenderedChild($producto->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

           
        </div>

        
        <footer class="footer d-flex justify-content-center align-items-center mt-5">
            <div class="row justify-content-center align-items-center">
              <p class="text-center">| Copyright @ 2020 - </p>
              
              <p class="text-center">TuProyectoWeb |</p>
            </div>
        </footer>

        <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\delibery\resources\views/welcome.blade.php ENDPATH**/ ?>