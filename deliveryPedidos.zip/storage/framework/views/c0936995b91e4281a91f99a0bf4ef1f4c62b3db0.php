<div class="">
    
    <div class=" container ">
        <hr>
        <div class=" row  py-2 rounded">
    <button class="btn btn-info mx-2 shadow" wire:click="resetFilter">Todos</button>
    <div class="dropdown shadow">
        <button class="btn btn-info dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false">
            Categorias
        </button>

        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a wire:click="$set('category_id',<?php echo e($categoria->id); ?>)" class="dropdown-item"
                    href="#"><?php echo e($categoria->nombre); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<input wire:model="search" class="form-control mt-3 w-50" type="search" placeholder="Buscar producto por nombre...">
<div class="table-responsive container-fluid">
    <table class="table bg-white mt-2 shadow-sm">
        <thead>
            <tr>
                <th>Codigo</th>
                <th>Nombre</th>
                <th>Categoria</th>
                <th >Precio</th>
                <th >Min</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($producto->codigo); ?></td>
                    <td><?php echo e($producto->nombre); ?></td>
                    <td><?php echo e($producto->categoria->nombre); ?></td>
                    <td >$<?php echo e($producto->precio); ?></td>
                    <td ><?php echo e($producto->minimo); ?></td>
                    <td>
                        <div class="row mx-auto">
                            <a href="<?php echo e(route('admin.productos.edit', $producto)); ?>"
                                class="btn btn-primary mr-2 mb-1 shadow">Editar</a>

                            <form action="<?php echo e(route('admin.productos.destroy', $producto)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input type="submit" class="btn btn-danger d-inline mr-1 shadow  " value="Eliminar">
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>


<div class=" mx-auto">
    <?php echo e($productos->onEachSide(0)->links()); ?>

</div>




</div>

</div>
<?php /**PATH C:\xampp\htdocs\deliveryPedidos\resources\views/livewire/producto-index.blade.php ENDPATH**/ ?>