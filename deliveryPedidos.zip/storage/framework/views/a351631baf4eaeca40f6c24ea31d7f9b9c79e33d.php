

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container my-4">
    <h1 class="tart">Listado de productos</h1>
</div>

<div class="container mt-2 ">
    <div class="row">
        <div class="mr-4 border-right p-3">
            <a href="<?php echo e(route('admin.productos.create')); ?>" class="btn btn-success shadow">Crear producto</a>
        </div>
        <div class="p-3">
            <form method="POST" action="<?php echo e(route('admin.importar')); ?>" enctype="multipart/form-data" novalidate>
                <?php echo csrf_field(); ?>

                <div class="row">
                    <div class="form-group mr-2 ">
                        <input type="submit" class="btn btn-success shadow rounded " value="Importación masiva">  
                    </div>
                    <div>
                        <input type="file" name="productos" id="" class="form-control ">
                    </div>
                </div>
                
                

            </form>
        </div>
        <div class="p-3 mr-3">
            <a href="<?php echo e(route('admin.eliminar-todos')); ?>" class="btn btn-danger shadow">Elimitar productos</a>
        </div>
    </div>

    

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('producto-index')->html();
} elseif ($_instance->childHasBeenRendered('GVC9cSw')) {
    $componentId = $_instance->getRenderedChildComponentId('GVC9cSw');
    $componentTag = $_instance->getRenderedChildComponentTagName('GVC9cSw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GVC9cSw');
} else {
    $response = \Livewire\Livewire::mount('producto-index');
    $html = $response->html();
    $_instance->logRenderedChild('GVC9cSw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>




<?php if(session('error')): ?>
    <script>
        toastr.error('<?php echo e(session('error')); ?>')
    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deliveryPedidos\resources\views/admin/productos/index.blade.php ENDPATH**/ ?>