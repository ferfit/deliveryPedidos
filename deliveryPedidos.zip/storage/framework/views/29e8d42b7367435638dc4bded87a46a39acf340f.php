

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="container mt-2">
        <h1 class="tart">Listado de categorias</h1>
    </div>

    <div class="container mt-3 ">
        <a href="<?php echo e(route('admin.categorias.create' )); ?>" class="btn btn-success shadow">Crear categoria</a>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('categoria-index')->html();
} elseif ($_instance->childHasBeenRendered('AsFBxBu')) {
    $componentId = $_instance->getRenderedChildComponentId('AsFBxBu');
    $componentTag = $_instance->getRenderedChildComponentTagName('AsFBxBu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AsFBxBu');
} else {
    $response = \Livewire\Livewire::mount('categoria-index');
    $html = $response->html();
    $_instance->logRenderedChild('AsFBxBu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
    

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deliveryPedidos\resources\views/admin/categorias/index.blade.php ENDPATH**/ ?>