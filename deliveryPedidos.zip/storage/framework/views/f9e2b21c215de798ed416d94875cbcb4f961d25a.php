<div>
    <div>
        <div class="container mx-auto">
            <input wire:model="search" class="form-control mt-3 w-50" type="search"
                placeholder="Buscar orden por...">
            <div class="table-responsive container-fluid">
                <table class="table bg-white mt-2 shadow-sm">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Nro</th>
                        <th>Franquiciado</th>
                        <th>Dirección</th>
                        <th>Total</th>
                        <th>Estado</th>
                        <th style="width: 200px">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td><?php echo e(date('d-m-Y', strtotime($orden->created_at))); ?></td>
                        

                        <td><?php echo e($orden->id); ?></td>
                        <td><?php echo e($orden->nombre); ?></td>
                        <td><?php echo e($orden->user->direccion); ?></td>
                        <td>$<?php echo e($orden->total); ?></td>
                        <td>
                            <?php switch( $orden->estado ):
                                case (1): ?>
                                    <small class="badge badge-warning"> Pendiente</small>
                                    <?php break; ?>
                                <?php case (2): ?>
                                    <small class="badge badge-primary"> En proceso</small>
                                    <?php break; ?>
                                <?php case (3): ?>
                                    <small class="badge badge-success"> Enviado</small>
                                    <?php break; ?>
                                <?php case (0): ?>
                                    <small class="badge badge-danger"> Cancelado</small>
                                    <?php break; ?>
                                <?php default: ?>
                                    
                            <?php endswitch; ?>
                            
                        </td>
                        <td>
                            <div class="row mx-auto">
                                <a href="<?php echo e(route('admin.ordens.show', $orden )); ?>" class="btn btn-secondary mr-2 text-white">Ver</a>
                                 <a href="<?php echo e(route('admin.ordens.edit', ['ordene' => $orden ] )); ?>" class="btn btn-primary mr-2">Editar</a> 
                            </div>
                            
                        </td>
                    </tr>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
            </div>
            <div class=" mx-auto">
                <?php echo e($ordenes->onEachSide(0)->links()); ?>

            </div>
        </div>
    
    </div>
    
</div>
<?php /**PATH C:\xampp\htdocs\deliveryPedidos\resources\views/livewire/orden-admin.blade.php ENDPATH**/ ?>