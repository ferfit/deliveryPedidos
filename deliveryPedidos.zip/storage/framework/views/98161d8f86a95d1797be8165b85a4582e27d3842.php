<div>
    <div class="dropdown">
        
        <img src="img/carrito.svg" class="position-relative" alt="" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <?php if(Cart::count()): ?>
        <span class="carrito__cantidad position-absolute"><?php echo e(Cart::count()); ?></span>
        <?php endif; ?>
        


        <div class="dropdown-menu shadow" aria-labelledby="dropdownMenuButton">

          <ul class="p-0 m-0">
            <?php $__empty_1 = true; $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <li class="d-flex carrito__lista border-bottom p-2">
                
                <article class="d-flex flex-wrap ">
                  <h1 class="col-12"><?php echo e($item->name); ?></h1>
                  <div class="d-flex col-12">
                    <p class="m-0">Cant:<?php echo e($item->qty); ?> </p>
                    <p class=" m-0 ml-2">Precio: $<?php echo e($item->price); ?></p>
                  </div>
                </article>
                
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <p class="dropdown-item m-0"> No tiene agregado ningún producto al carrito.</p>
            <?php endif; ?>
          </ul>
          
          <?php if(Cart::count()): ?> 
          <div class="carrito__total">
            <p class="">Total: $<?php echo e(Cart::subtotal()); ?></p>
          </div>

          <div class=" mt-2">
            <a type="button" href="<?php echo e(route('carrito')); ?>" class="btn btn-danger carrito__ver-carrito font-bold d-block mx-auto"
            >IR AL CARRITO</a>
          </div>
            
          <?php endif; ?>



        </div>
    </div>

    <span class="valor-carrito" id="valor-carrito"></span>

</div>
<?php /**PATH C:\xampp\htdocs\delibery\resources\views/livewire/dropdown-cart.blade.php ENDPATH**/ ?>