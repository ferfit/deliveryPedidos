<div class="py-5">
    
    <div class="container ">
        
        <div class="row  py-2 rounded">
            <button class="btn btn-info mx-2 shadow" wire:click = "resetFilter">Todos</button>
            <div class="dropdown shadow">
                <button class="btn btn-info dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Categorias
                </button>

                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a wire:click = "$set('category_id',<?php echo e($categoria->id); ?>)" class="dropdown-item" href="#"><?php echo e($categoria->nombre); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>


        <?php echo e($tamaño); ?>



        

        

        <table class="table bg-white mt-2 shadow">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th >Descripción</th>
                    <th class="d-none d-lg-block">Precio</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($producto->nombre); ?></td>
                        <td ><?php echo e($producto->descripcion); ?></td>
                        <td class="d-none d-lg-block">$<?php echo e($producto->precio); ?></td>
                        <td>
                            <div class="row">
                                <a href="<?php echo e(route ('admin.productos.edit', $producto)); ?>" class="btn btn-primary mr-2 mb-1 shadow">Editar</a>
                            
                                <form action="<?php echo e(route ('admin.productos.destroy', $producto)); ?>" method="POST" >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <input type="submit" class="btn btn-danger d-inline mr-1 shadow  "
                                        value="Eliminar">
                                </form>
                            </div>
                        </td>
                    </tr> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </tbody>
        </table>

        
            <div class=" mx-auto">
                <?php echo e($productos->onEachSide(0)->links()); ?>

            </div>
        
        
        

    </div>
    
</div>
<?php /**PATH C:\xampp\htdocs\delibery\resources\views/livewire/producto-index.blade.php ENDPATH**/ ?>