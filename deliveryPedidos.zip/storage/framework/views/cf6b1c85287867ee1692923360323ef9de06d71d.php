<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet" />
    <?php echo \Livewire\Livewire::styles(); ?>

    
    <style>
        .toastr-success {
            bottom: 10px !important;
        }
        
        </style>
    <!-- Alpine js -->
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.8.2/dist/alpine.min.js"></script>


</head>

<body class="antialiased">



    

    <div class="container-fluid p-0 m-0 cabecera rounded ">

        <?php if(Route::has('login')): ?>
            <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block ml-2">
                <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->tipo == 'franquiciado'): ?>
                        
                            <a class="text-sm text-gray-700 underline bg-danger p-1 rounded text-light text-decoration-none" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                                Cerrar sesión
                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        
                    <?php else: ?>
                        <a href="<?php echo e(url('/admin')); ?>"
                            class="text-sm text-gray-700 underline bg-danger p-1 rounded text-light text-decoration-none">Dashboard</a>
                            
                            <a class="text-sm text-gray-700 underline bg-danger p-1 rounded text-light text-decoration-none" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                                Cerrar sesión
                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                    <?php endif; ?>

                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>"
                        class="text-sm text-gray-700 underline bg-danger p-1 rounded text-light text-decoration-none">Login</a>


                <?php endif; ?>
            </div>

        <?php endif; ?>
        <div class="d-flex justify-content-center align-items-center overflow-hidden" style="margin-top: 170px">
            <img src="img/logo.webp" alt="" class="">
        </div>

    </div>

    
    <div id="carrito-icono" class="carrito container shadow rounded p-2 bg-white">
        
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dropdown-cart')->html();
} elseif ($_instance->childHasBeenRendered('bQlVfJf')) {
    $componentId = $_instance->getRenderedChildComponentId('bQlVfJf');
    $componentTag = $_instance->getRenderedChildComponentTagName('bQlVfJf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('bQlVfJf');
} else {
    $response = \Livewire\Livewire::mount('dropdown-cart');
    $html = $response->html();
    $_instance->logRenderedChild('bQlVfJf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    


    
    <div class="container" id="cont-producto">
        
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('index-producto')->html();
} elseif ($_instance->childHasBeenRendered('rFhqETB')) {
    $componentId = $_instance->getRenderedChildComponentId('rFhqETB');
    $componentTag = $_instance->getRenderedChildComponentTagName('rFhqETB');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rFhqETB');
} else {
    $response = \Livewire\Livewire::mount('index-producto');
    $html = $response->html();
    $_instance->logRenderedChild('rFhqETB', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


    </div>



    
    <footer class="footer d-flex justify-content-center align-items-center mt-5">
        <div class="row justify-content-center align-items-center">
            <p class="text-center">| Copyright @ 2020 - </p>

            <p class="text-center">TuProyectoWeb |</p>
        </div>
    </footer>

    <?php echo \Livewire\Livewire::scripts(); ?>


    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <script>
        Livewire.on('toastr', () => {
            toastr.options = {
                "positionClass": "toast-bottom-right"
            }
            toastr.success('Producto agregado  al carrito exitosamente !!! ')
        })

        Livewire.on('toastr-error', () => {
            toastr.options = {
                "positionClass": "toast-bottom-right"
            }
            toastr.danger('Debe seleccionar una cantidad mayor a 0 !!! ')
        })
    </script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\deliveryPedidos\resources\views/welcome.blade.php ENDPATH**/ ?>