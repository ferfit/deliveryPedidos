<div class="mt-5">
    <div class="row  py-2 rounded">
        <button class="btn btn-dark mx-2 shadow" wire:click="resetFilter">Todos</button>
        <div class="dropdown shadow">
            <button class="btn btn-dark dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                Categorias
            </button>

            <div class="dropdown-menu shadow" aria-labelledby="dropdownMenuButton">
                <div class="d-flex flex-wrap w-100">
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a wire:click="$set('category_id',<?php echo e($categoria->id); ?>)" class="dropdown-item d-block w-50"
                            href="#"><?php echo e($categoria->nombre); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <input wire:model.defer="search"  wire:keydown.enter="render" class="form-control mt-3 w-50" type="search"  placeholder="Buscar producto por nombre...">
    <div class="table-responsive container-fluid">
        <table class="table bg-white mt-2 shadow-sm ">
            <thead>
                <tr>
                    <th>Codigo</th>
                    <th>Producto</th>
                    <th>Categoria</th>
                    <th >Precio</th>
                    <th>Min</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
              
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($producto->codigo); ?></td>
                        <td><?php echo e($producto->nombre); ?></td>
                        <td><span class="bg-dark text-white p-2 rounded"><?php echo e($producto->categoria->nombre); ?></span></td>
                        <td>$<?php echo e($producto->precio); ?></td>
                        <td>10u</td>
                        <td>
                            <div class="row ">

                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cantidad-producto',['producto' => $producto])->html();
} elseif ($_instance->childHasBeenRendered($producto->id)) {
    $componentId = $_instance->getRenderedChildComponentId($producto->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($producto->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($producto->id);
} else {
    $response = \Livewire\Livewire::mount('cantidad-producto',['producto' => $producto]);
    $html = $response->html();
    $_instance->logRenderedChild($producto->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                                

                                


                                <!-- Button trigger modal -->
                                

                                <!-- Modal -->
                                

                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               


            </tbody>
        </table>
    </div>
    <div class=" mx-auto">
        <?php echo e($productos->onEachSide(0)->links()); ?>

    </div> 


    
</div>
<?php /**PATH C:\xampp\htdocs\deliveryPedidos\resources\views/livewire/index-producto.blade.php ENDPATH**/ ?>