<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
        <?php echo \Livewire\Livewire::styles(); ?>



        
    </head>
    <body class="antialiased">

    

        

        

        
        

       
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('carrito')->html();
} elseif ($_instance->childHasBeenRendered('NY3e2za')) {
    $componentId = $_instance->getRenderedChildComponentId('NY3e2za');
    $componentTag = $_instance->getRenderedChildComponentTagName('NY3e2za');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NY3e2za');
} else {
    $response = \Livewire\Livewire::mount('carrito');
    $html = $response->html();
    $_instance->logRenderedChild('NY3e2za', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        
        

            <!-- <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('carrito-campos')->html();
} elseif ($_instance->childHasBeenRendered('E1OrurO')) {
    $componentId = $_instance->getRenderedChildComponentId('E1OrurO');
    $componentTag = $_instance->getRenderedChildComponentTagName('E1OrurO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('E1OrurO');
} else {
    $response = \Livewire\Livewire::mount('carrito-campos');
    $html = $response->html();
    $_instance->logRenderedChild('E1OrurO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> -->

        

        <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\deliveryPedidos\resources\views/carrito.blade.php ENDPATH**/ ?>