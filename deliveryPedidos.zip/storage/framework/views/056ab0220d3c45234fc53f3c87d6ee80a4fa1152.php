

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Panel de administración general</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-3 col-6">

            
            <?php if($ordenes->count()): ?>

                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?php echo e($ordenes->count()); ?></h3>

                        <p>Ordenes</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                </div>

            <?php else: ?>

                <div class="small-box bg-info">
                    <div class="inner">
                        <h3>0</h3>

                        <p>Ordenes</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                </div>

            <?php endif; ?>

        </div>


        <!-- Categorias -->
        <div class="col-lg-3 col-6">

            <?php if($categorias->count()): ?>
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3><?php echo e($categorias->count()); ?></h3>

                        <p>Categorias</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-stats-bars"></i>
                    </div>
                </div>

            <?php else: ?>
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3>0</h3>

                        <p>Categorias</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-stats-bars"></i>
                    </div>
                </div>

            <?php endif; ?>


        </div>


        <!-- Productos -->
        <div class="col-lg-3 col-6">

            <?php if($productos->count()): ?>
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3><?php echo e($productos->count()); ?></h3>

                        <p>Productos</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-pie-graph"></i>
                    </div>
                </div>
            <?php else: ?>
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3>0</h3>

                        <p>Productos</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-pie-graph"></i>
                    </div>
                </div>

            <?php endif; ?>

        </div>



        <!-- Usuarios -->

        <div class="col-lg-3 col-6">
            <?php if($usuarios->count()): ?>
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3><?php echo e($usuarios->count()); ?></h3>

                        <p>Usuarios</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person-add"></i>
                    </div>
                </div>
            <?php else: ?>
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3>0</h3>

                        <p>Usuarios</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person-add"></i>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <!-- ./col -->

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deliveryPedidos\resources\views/admin/index.blade.php ENDPATH**/ ?>