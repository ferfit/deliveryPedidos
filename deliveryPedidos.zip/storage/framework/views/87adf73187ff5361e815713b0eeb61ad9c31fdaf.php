<div class="d-flex flex-wrap justify-content-center m-0 p-0">
            
    <?php $__currentLoopData = $categoria->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
        
        <div   class="col-5 col-md-2 bg-white menu-item mx-md-2 my-3 shadow p-3 rounded d-flex flex-column justify-content-center align-items-center">
            <img src="/storage/<?php echo e($producto->imagen); ?>" alt="" class="w-75 rounded-circle d-block mx-auto ">
            <h3 class="nombre_producto mt-2 text-center" data_titulo="<?php echo e($producto->titulo); ?>" ><?php echo e($producto->nombre); ?></h3>
            <p class="descripcion_producto m-0 text-center"><?php echo e(Str::limit ( strip_tags ( $producto->descripcion ), 100 )); ?></p>
            <p class="text-center mt-2"><strong>$ <span class="text-center mx-auto"><?php echo e($producto->precio); ?></span></strong></p>
             
            

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cantidad-producto', ['producto' => $producto])->html();
} elseif ($_instance->childHasBeenRendered($producto->id)) {
    $componentId = $_instance->getRenderedChildComponentId($producto->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($producto->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($producto->id);
} else {
    $response = \Livewire\Livewire::mount('cantidad-producto', ['producto' => $producto]);
    $html = $response->html();
    $_instance->logRenderedChild($producto->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="d-flex align-items-center mb-2">
        <button type="button" class="btn btn-danger rounded"> - </button>
        <span class="mx-2"><?php echo e($qty); ?></span>
        <button type="button" class="btn btn-danger rounded"
        wire:click="increment"> + </button>
    </div>

    

</div>


<?php /**PATH C:\xampp\htdocs\delibery\resources\views/livewire/category-products.blade.php ENDPATH**/ ?>