<div>
    <div class="container">
        <table class="table bg-white mt-2 shadow">
            <thead>
                <tr>
                    <th>Franquicia</th>
                    <th>Razón Social</th>
                    <th>Cuit</th>
                    <th>Dirección</th>
                    <th>Localidad</th>
                    <th>Provincia</th>
                    <th>Whatsapp</th>
                    <th>Email</th>
                    <th style="width:200px;">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td><?php echo e($usuario->name); ?></td>
                        <td><?php echo e($usuario->razonSocial); ?></td>
                        <td><?php echo e($usuario->cuit); ?></td>
                        <td><?php echo e($usuario->direccion); ?></td>
                        <td><?php echo e($usuario->localidad); ?></td>
                        <td><?php echo e($usuario->provincia); ?></td>
                        <td><?php echo e($usuario->whatsapp); ?></td>
                        <td><?php echo e($usuario->email); ?></td>
                        
                        

                        <td>
                            <div class="row mx-auto">
                                <a href="<?php echo e(route ('admin.usuarios.edit', $usuario)); ?>" class="btn btn-primary mr-2 mb-1 shadow">Editar</a>
                            
                                <form action="<?php echo e(route ('admin.usuarios.destroy', $usuario)); ?>" method="POST" >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <input type="submit" class="btn btn-danger d-inline mr-1 shadow  "
                                        value="Eliminar">
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

        <div class=" mx-auto">
            <?php echo e($usuarios->links()); ?>

        </div>

    </div>

</div>
<?php /**PATH C:\xampp\htdocs\deliveryPedidos\resources\views/livewire/usuario-index.blade.php ENDPATH**/ ?>