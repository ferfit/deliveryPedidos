

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container my-4">
    <h1 class="tart">Listado de ordenes</h1>
</div>

<div class="container mt-2 ">

    
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('orden-admin')->html();
} elseif ($_instance->childHasBeenRendered('cORTgDQ')) {
    $componentId = $_instance->getRenderedChildComponentId('cORTgDQ');
    $componentTag = $_instance->getRenderedChildComponentTagName('cORTgDQ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cORTgDQ');
} else {
    $response = \Livewire\Livewire::mount('orden-admin');
    $html = $response->html();
    $_instance->logRenderedChild('cORTgDQ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deliveryPedidos\resources\views/admin/ordenes/index.blade.php ENDPATH**/ ?>