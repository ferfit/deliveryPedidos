<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
        <?php echo \Livewire\Livewire::styles(); ?>



        
    </head>
    <body class="antialiased">

    

        

        

        
        

       
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('carrito')->html();
} elseif ($_instance->childHasBeenRendered('Vd8qzrC')) {
    $componentId = $_instance->getRenderedChildComponentId('Vd8qzrC');
    $componentTag = $_instance->getRenderedChildComponentTagName('Vd8qzrC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Vd8qzrC');
} else {
    $response = \Livewire\Livewire::mount('carrito');
    $html = $response->html();
    $_instance->logRenderedChild('Vd8qzrC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        
        

            <!-- <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('carrito-campos')->html();
} elseif ($_instance->childHasBeenRendered('fWIjmwl')) {
    $componentId = $_instance->getRenderedChildComponentId('fWIjmwl');
    $componentTag = $_instance->getRenderedChildComponentTagName('fWIjmwl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fWIjmwl');
} else {
    $response = \Livewire\Livewire::mount('carrito-campos');
    $html = $response->html();
    $_instance->logRenderedChild('fWIjmwl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> -->

        

        <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\delibery\resources\views/carrito.blade.php ENDPATH**/ ?>