<?php return array (
  'cantidad-producto' => 'App\\Http\\Livewire\\CantidadProducto',
  'carrito' => 'App\\Http\\Livewire\\Carrito',
  'carrito-campos' => 'App\\Http\\Livewire\\CarritoCampos',
  'carrito-cantidad' => 'App\\Http\\Livewire\\CarritoCantidad',
  'categoria-index' => 'App\\Http\\Livewire\\CategoriaIndex',
  'dropdown-cart' => 'App\\Http\\Livewire\\DropdownCart',
  'index-producto' => 'App\\Http\\Livewire\\IndexProducto',
  'orden-admin' => 'App\\Http\\Livewire\\OrdenAdmin',
  'producto-index' => 'App\\Http\\Livewire\\ProductoIndex',
  'usuario-index' => 'App\\Http\\Livewire\\UsuarioIndex',
);